import grequests
import requests
import json
from web3 import Web3
import database as db
import time


class script:
    def __init__(self, id):
        self.api = 'ZJYEU4R2GAKUG1EJ19XKXBGEDPDRZYDNAY'
        self.contractID = id
        self.contract = None
        self.maxSupply = None
        self.tokenURI = None
        self.query = 0

    def readContract(self):
        w3 = Web3(Web3.HTTPProvider('https://mainnet.infura.io/v3/8055faca626042d88e8adec7985deb0b'))
        r = requests.get(
            'https://api.etherscan.io/api?module=contract&action=getabi&address=' + self.contractID + '&apikey=' + self.api)
        data = r.json()['result']
        self.contract = w3.eth.contract(self.contractID, abi=data)

    def findMaxSupply(self):
        self.maxSupply = self.contract.functions.totalSupply().call()

    def findTokenURI(self):
        self.tokenURI = self.contract.functions.tokenURI(1).call()
        if 'ipfs' in self.tokenURI:
            self.tokenURI = self.tokenURI.replace('ipfs://', '')
            self.tokenURI = 'https://ipfs.io/ipfs/' + self.tokenURI

        self.tokenURI = self.tokenURI[:-1]

    def requestServer(self, urls, DB):
        rs = (grequests.get(u) for u in urls)
        z = grequests.map(rs)
        for i in z:
            try:
                x = i.json()
                for k in x['attributes']:
                    DB.setTraitTypes(self.contractID, str(self.query + 1), k['trait_type'], k['value'])
                self.query += 1
            except:
                self.query += 1
                continue

    def findTypeTraitTypes(self, DB):
        urls = []
        for i in range(self.maxSupply):
            if '1.json' in self.tokenURI:
                x = self.tokenURI.replace('1.json', '')
                x = x + str(i + 1) + '.json'
            else:
                x = self.tokenURI + str(i + 1)
            urls.append(x)

            if i % 100 == 0:
                print(i)
                self.requestServer(urls, DB)
                urls.clear()


start = time.time()
DB = db.init()

# Input Contract
data = input("Enter Contract ID & Hit Enter:\n")
# Check if Contract Exist
flag = False
maxSupply = None
tokenURL = None
for i in DB.getContracts():
    if data == i[1]:
        flag = True
        maxSupply = i[2]
        tokenURL = i[3]

try:

    if not flag:
        obj = script(data)
        obj.readContract()
        obj.findMaxSupply()
        obj.findTokenURI()
        DB.setContract(obj.contractID, obj.maxSupply, obj.tokenURI)
        obj.findTypeTraitTypes(DB)
    else:
        obj = script(data)
        obj.maxSupply = maxSupply
        obj.tokenURI = tokenURL
        print(obj.maxSupply)
        print(obj.tokenURI)
        obj.findTypeTraitTypes(DB)

except:
    pass

print(time.time() - start)
