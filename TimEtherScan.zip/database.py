import mysql.connector
import json


class Database:
    def __init__(self):
        self.cursor = None
        self.db = None

    # Method to connect with the database.
    def connection(self, host, user, password, dbName):
        try:
            mydb = mysql.connector.connect(
                host=host,
                user=user,
                password=password,
                database=dbName
            )
            # create executor on successful connection.
            self.cursor = mydb.cursor()
            self.db = mydb
            # create database if not exist.
            self.cursor.execute("SHOW DATABASES")
            dbExist = False
            for x in self.cursor:
                if x[0] == dbName.lower():
                    dbExist = True
            if dbExist is False:
                self.createDatabase(dbName)
                mydb = mysql.connector.connect(
                    host=host,
                    user=user,
                    password=password,
                    database=dbName
                )
                self.cursor = mydb.cursor(buffered=True,dictionary=True)
                self.db = mydb
            print("Database Connection Successful.")
            return True
        except:
            print("Error Connecting to Database.")
            return False

    # Method to Create Database
    def createDatabase(self, databaseName):
        self.cursor.execute("CREATE DATABASE " + databaseName)

    def setContract(self,contractID,limit,url):
        self.cursor.execute("INSERT INTO CONTRACTS set contractID=%s,max_limit=%s,tokenURI=%s",(contractID,limit,url))

    def setTraitTypes(self,cID,q,type,value):
        self.cursor.execute("INSERT INTO traits set cID=%s,query=%s,type=%s,value=%s",(cID,q,type,value))

    def getContracts(self):
        self.cursor.execute("SELECT * from contracts")
        return self.cursor.fetchall()

def init():
    f = open('config.json')
    config = json.load(f)

    dbObject = Database()
    if dbObject.connection(host=config['database'].get('host'), user=config['database'].get('user'),
                        password=config['database'].get('password'), dbName=config['database'].get('name')):
        return dbObject
    else:
        return False

